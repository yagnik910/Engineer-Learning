import React from 'react';
import { BookOpen, Video, FileText, Calculator, Users, Award, Play, Star, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';

const StudyResources: React.FC = () => {
  const resources = [
    {
      icon: BookOpen,
      title: 'Interactive Textbooks',
      description: 'Digital textbooks with embedded simulations and practice problems',
      count: '200+',
      color: 'from-blue-500 to-blue-600',
      rating: 4.8,
      students: '25k+',
      features: ['Interactive diagrams', 'Built-in calculators', 'Progress tracking', 'Offline access']
    },
    {
      icon: Video,
      title: 'Video Lectures',
      description: 'High-quality video content from top engineering professors worldwide',
      count: '500+',
      color: 'from-red-500 to-pink-500',
      rating: 4.9,
      students: '50k+',
      features: ['HD quality', 'Subtitles', 'Playback speed control', 'Mobile friendly']
    },
    {
      icon: FileText,
      title: 'Study Guides',
      description: 'Comprehensive guides covering all major engineering topics',
      count: '150+',
      color: 'from-green-500 to-emerald-500',
      rating: 4.7,
      students: '18k+',
      features: ['Exam focused', 'Quick reference', 'Formula sheets', 'Practice tests']
    },
    {
      icon: Calculator,
      title: 'Engineering Tools',
      description: 'Professional calculators, simulators, and design tools',
      count: '50+',
      color: 'from-purple-500 to-indigo-500',
      rating: 4.8,
      students: '30k+',
      features: ['Real-time calculations', 'Visual outputs', 'Export results', 'Mobile optimized']
    },
    {
      icon: Users,
      title: 'Study Groups',
      description: 'Connect with peers and collaborate on engineering projects',
      count: '1000+',
      color: 'from-orange-500 to-red-500',
      rating: 4.6,
      students: '12k+',
      features: ['Discussion forums', 'Project collaboration', 'Peer tutoring', 'Study schedules']
    },
    {
      icon: Award,
      title: 'Certifications',
      description: 'Earn recognized certificates in various engineering skills',
      count: '25+',
      color: 'from-yellow-500 to-orange-500',
      rating: 4.9,
      students: '8k+',
      features: ['Industry recognized', 'Skill verification', 'LinkedIn integration', 'Career boost']
    },
  ];

  const featuredCourses = [
    {
      title: 'Complete Civil Engineering',
      instructor: 'Dr. Sarah Johnson',
      rating: 4.9,
      students: 12500,
      duration: '40 hours',
      price: 'Free',
      image: 'https://images.pexels.com/photos/3862132/pexels-photo-3862132.jpeg?auto=compress&cs=tinysrgb&w=300',
      slug: 'civil-engineering'
    },
    {
      title: 'Software Engineering Fundamentals',
      instructor: 'Prof. Michael Chen',
      rating: 4.8,
      students: 25000,
      duration: '60 hours',
      price: 'Free',
      image: 'https://images.pexels.com/photos/2582937/pexels-photo-2582937.jpeg?auto=compress&cs=tinysrgb&w=300',
      slug: 'software-engineering'
    },
    {
      title: 'Electrical Engineering Basics',
      instructor: 'Dr. Emily Rodriguez',
      rating: 4.7,
      students: 18000,
      duration: '35 hours',
      price: 'Free',
      image: 'https://images.pexels.com/photos/3735218/pexels-photo-3735218.jpeg?auto=compress&cs=tinysrgb&w=300',
      slug: 'electrical-engineering'
    }
  ];

  return (
    <section id="resources" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Study Resources
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Access a vast library of learning materials designed to help you master engineering concepts 
            and excel in your studies. All resources are created by industry experts and top professors.
          </p>
        </div>

        {/* Resources Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {resources.map((resource, index) => (
            <div
              key={index}
              className="group bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1"
            >
              <div className={`inline-flex items-center justify-center w-12 h-12 rounded-lg bg-gradient-to-r ${resource.color} mb-4`}>
                <resource.icon className="h-6 w-6 text-white" />
              </div>
              
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xl font-semibold text-gray-900">{resource.title}</h3>
                <span className={`text-sm font-bold bg-gradient-to-r ${resource.color} bg-clip-text text-transparent`}>
                  {resource.count}
                </span>
              </div>
              
              <p className="text-gray-600 mb-4">{resource.description}</p>
              
              {/* Stats */}
              <div className="flex items-center justify-between mb-4 text-sm text-gray-600">
                <div className="flex items-center">
                  <Star className="h-4 w-4 text-yellow-400 mr-1" />
                  <span>{resource.rating}</span>
                </div>
                <div className="flex items-center">
                  <Users className="h-4 w-4 mr-1" />
                  <span>{resource.students}</span>
                </div>
              </div>
              
              {/* Features */}
              <div className="mb-4">
                <div className="flex flex-wrap gap-1">
                  {resource.features.slice(0, 2).map((feature, idx) => (
                    <span
                      key={idx}
                      className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded"
                    >
                      {feature}
                    </span>
                  ))}
                  {resource.features.length > 2 && (
                    <span className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded">
                      +{resource.features.length - 2} more
                    </span>
                  )}
                </div>
              </div>
              
              <button className="w-full text-blue-600 hover:text-blue-700 font-medium group-hover:translate-x-1 transition-transform duration-200 text-left">
                Explore {resource.title} →
              </button>
            </div>
          ))}
        </div>

        {/* Featured Courses */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-2xl font-bold text-gray-900">Featured Courses</h3>
            <Link to="/courses" className="text-blue-600 hover:text-blue-700 font-medium">
              View All Courses →
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredCourses.map((course, index) => (
              <div key={index} className="bg-white rounded-xl shadow-sm hover:shadow-lg transition-shadow duration-300 overflow-hidden group">
                <div className="aspect-video relative overflow-hidden">
                  <img
                    src={course.image}
                    alt={course.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="bg-white/90 rounded-full p-3">
                      <Play className="h-6 w-6 text-blue-600" />
                    </div>
                  </div>
                  <div className="absolute top-4 right-4 bg-green-500 text-white px-2 py-1 rounded text-sm font-medium">
                    {course.price}
                  </div>
                </div>
                
                <div className="p-6">
                  <h4 className="text-lg font-semibold text-gray-900 mb-2">{course.title}</h4>
                  <p className="text-sm text-gray-600 mb-3">by {course.instructor}</p>
                  
                  <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-400 mr-1" />
                      <span>{course.rating}</span>
                      <span className="ml-1">({course.students.toLocaleString()})</span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>{course.duration}</span>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Link
                      to={`/course/${course.slug}`}
                      className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg text-center hover:bg-blue-700 transition-colors duration-200"
                    >
                      Enroll Now
                    </Link>
                    <Link
                      to={`/lectures/${course.slug}`}
                      className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors duration-200"
                    >
                      Preview
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-gradient-to-r from-blue-600 to-teal-600 rounded-2xl p-8 text-white text-center">
          <h3 className="text-2xl font-bold mb-4">
            🎓 Start Your Engineering Journey Today
          </h3>
          <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
            Join thousands of students worldwide who are mastering engineering with our comprehensive 
            resources, expert instruction, and hands-on projects.
          </p>
          <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-4">
            <button className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors duration-200">
              Browse All Courses
            </button>
            <button className="border border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white/10 transition-colors duration-200">
              Try Free Tools
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default StudyResources;