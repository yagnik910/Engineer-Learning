import React from 'react';
import { ChevronRight, Play } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative pt-20 pb-16 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-white to-teal-50"></div>
      
      {/* Content */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          {/* Badge */}
          <div className="inline-flex items-center space-x-2 bg-blue-100 text-blue-800 rounded-full px-4 py-2 text-sm font-medium mb-8">
            <span>🚀 New: AI-Powered Study Assistant</span>
            <ChevronRight className="h-4 w-4" />
          </div>

          {/* Main Heading */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
            Master{' '}
            <span className="bg-gradient-to-r from-blue-600 to-teal-600 bg-clip-text text-transparent">
              Every Engineering
            </span>
            <br />
            Discipline
          </h1>

          {/* Subtitle */}
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
            Your comprehensive platform for studying all types of engineering. From Civil to Software, 
            Mechanical to Aerospace - access world-class resources, tools, and career guidance.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-4 mb-12">
            <button className="bg-gradient-to-r from-blue-600 to-teal-600 text-white px-8 py-4 rounded-lg font-semibold hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200 flex items-center space-x-2">
              <span>Start Learning</span>
              <ChevronRight className="h-5 w-5" />
            </button>
            
            <button className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 transition-colors duration-200">
              <div className="bg-white rounded-full p-3 shadow-md hover:shadow-lg transition-shadow duration-200">
                <Play className="h-5 w-5 text-blue-600" />
              </div>
              <span className="font-medium">Watch Demo</span>
            </button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
            {[
              { number: '12+', label: 'Engineering Fields' },
              { number: '1000+', label: 'Study Resources' },
              { number: '50+', label: 'Interactive Tools' },
              { number: '10k+', label: 'Students Helped' },
            ].map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-2xl font-bold text-gray-900">{stat.number}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;