import React from 'react';
import EngineeringCard from './EngineeringCard';
import {
  Building,
  Cog,
  Zap,
  Code,
  Beaker,
  Plane,
  Hammer,
  Cpu,
  TreePine,
  Factory,
  Dna,
  Car,
} from 'lucide-react';

const EngineeringDisciplines: React.FC = () => {
  const disciplines = [
    {
      title: 'Civil Engineering',
      description: 'Design and build the infrastructure that shapes our world',
      icon: Building,
      color: 'from-blue-500 to-blue-600',
      topics: ['Structural Design', 'Construction Management', 'Transportation', 'Geotechnical', 'Water Resources'],
      resources: 156,
      lectures: 89,
      students: 12,
      rating: 4.8,
      slug: 'civil-engineering',
    },
    {
      title: 'Mechanical Engineering',
      description: 'Create machines and systems that power modern life',
      icon: Cog,
      color: 'from-orange-500 to-red-500',
      topics: ['Thermodynamics', 'Mechanics', 'Materials Science', 'CAD Design', 'Manufacturing'],
      resources: 142,
      lectures: 76,
      students: 15,
      rating: 4.7,
      slug: 'mechanical-engineering',
    },
    {
      title: 'Electrical Engineering',
      description: 'Harness the power of electricity and electronics',
      icon: Zap,
      color: 'from-yellow-500 to-orange-500',
      topics: ['Circuit Analysis', 'Power Systems', 'Electronics', 'Control Systems', 'Signal Processing'],
      resources: 134,
      lectures: 82,
      students: 18,
      rating: 4.9,
      slug: 'electrical-engineering',
    },
    {
      title: 'Software Engineering',
      description: 'Build the digital solutions of tomorrow',
      icon: Code,
      color: 'from-green-500 to-teal-500',
      topics: ['Algorithms', 'Data Structures', 'Software Design', 'Web Development', 'AI/ML'],
      resources: 198,
      lectures: 124,
      students: 25,
      rating: 4.9,
      slug: 'software-engineering',
    },
    {
      title: 'Chemical Engineering',
      description: 'Transform raw materials into valuable products',
      icon: Beaker,
      color: 'from-purple-500 to-pink-500',
      topics: ['Process Design', 'Mass Transfer', 'Reaction Engineering', 'Thermodynamics', 'Safety'],
      resources: 89,
      lectures: 54,
      students: 8,
      rating: 4.6,
      slug: 'chemical-engineering',
    },
    {
      title: 'Aerospace Engineering',
      description: 'Design aircraft and spacecraft for flight and space exploration',
      icon: Plane,
      color: 'from-indigo-500 to-purple-500',
      topics: ['Aerodynamics', 'Propulsion', 'Flight Mechanics', 'Materials', 'Space Systems'],
      resources: 76,
      lectures: 45,
      students: 6,
      rating: 4.8,
      slug: 'aerospace-engineering',
    },
    {
      title: 'Industrial Engineering',
      description: 'Optimize complex systems and processes for efficiency',
      icon: Factory,
      color: 'from-gray-600 to-gray-700',
      topics: ['Operations Research', 'Quality Control', 'Supply Chain', 'Ergonomics', 'Lean Manufacturing'],
      resources: 67,
      lectures: 38,
      students: 7,
      rating: 4.5,
      slug: 'industrial-engineering',
    },
    {
      title: 'Computer Engineering',
      description: 'Bridge hardware and software in computing systems',
      icon: Cpu,
      color: 'from-blue-600 to-indigo-600',
      topics: ['Computer Architecture', 'Embedded Systems', 'VLSI Design', 'Networking', 'Digital Systems'],
      resources: 112,
      lectures: 67,
      students: 14,
      rating: 4.7,
      slug: 'computer-engineering',
    },
    {
      title: 'Environmental Engineering',
      description: 'Protect and improve our environment through engineering solutions',
      icon: TreePine,
      color: 'from-green-600 to-emerald-600',
      topics: ['Water Treatment', 'Air Quality', 'Waste Management', 'Sustainability', 'Environmental Impact'],
      resources: 58,
      lectures: 34,
      students: 5,
      rating: 4.6,
      slug: 'environmental-engineering',
    },
    {
      title: 'Biomedical Engineering',
      description: 'Apply engineering principles to healthcare and medicine',
      icon: Dna,
      color: 'from-pink-500 to-rose-500',
      topics: ['Medical Devices', 'Biomaterials', 'Bioprocessing', 'Imaging Systems', 'Tissue Engineering'],
      resources: 72,
      lectures: 42,
      students: 9,
      rating: 4.7,
      slug: 'biomedical-engineering',
    },
    {
      title: 'Mining Engineering',
      description: 'Extract valuable minerals and resources from the earth',
      icon: Hammer,
      color: 'from-amber-600 to-yellow-600',
      topics: ['Mine Planning', 'Rock Mechanics', 'Mineral Processing', 'Safety Systems', 'Surveying'],
      resources: 45,
      lectures: 28,
      students: 3,
      rating: 4.4,
      slug: 'mining-engineering',
    },
    {
      title: 'Automotive Engineering',
      description: 'Design and develop the vehicles of the future',
      icon: Car,
      color: 'from-red-500 to-orange-500',
      topics: ['Vehicle Dynamics', 'Powertrain', 'Safety Systems', 'Electric Vehicles', 'Autonomous Systems'],
      resources: 93,
      lectures: 56,
      students: 11,
      rating: 4.6,
      slug: 'automotive-engineering',
    },
  ];

  return (
    <section id="disciplines" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Engineering Disciplines
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Explore comprehensive study materials, video lectures, and interactive tools for every major engineering field. 
            Learn from top-rated instructors and join thousands of students worldwide.
          </p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {disciplines.map((discipline, index) => (
            <EngineeringCard key={index} {...discipline} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default EngineeringDisciplines;