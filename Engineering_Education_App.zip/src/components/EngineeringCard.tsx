import React from 'react';
import { DivideIcon as LucideIcon, ChevronRight, Play, BookOpen, Users } from 'lucide-react';
import { Link } from 'react-router-dom';

interface EngineeringCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  color: string;
  topics: string[];
  resources: number;
  lectures: number;
  students: number;
  rating: number;
  slug: string;
}

const EngineeringCard: React.FC<EngineeringCardProps> = ({
  title,
  description,
  icon: Icon,
  color,
  topics,
  resources,
  lectures,
  students,
  rating,
  slug,
}) => {
  return (
    <div className="group bg-white rounded-xl shadow-sm hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border border-gray-100 overflow-hidden">
      {/* Header */}
      <div className={`p-6 bg-gradient-to-br ${color}`}>
        <div className="flex items-center justify-between">
          <div className="bg-white/20 backdrop-blur-sm rounded-lg p-3">
            <Icon className="h-8 w-8 text-white" />
          </div>
          <div className="text-right">
            <div className="text-white/80 text-sm font-medium">
              {resources} resources
            </div>
            <div className="flex items-center text-white/90 text-xs mt-1">
              <span className="text-yellow-300">★</span>
              <span className="ml-1">{rating}</span>
            </div>
          </div>
        </div>
        <h3 className="text-xl font-bold text-white mt-4">{title}</h3>
        <p className="text-white/90 text-sm mt-2">{description}</p>
      </div>

      {/* Content */}
      <div className="p-6">
        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="text-center">
            <div className="text-lg font-bold text-gray-900">{lectures}</div>
            <div className="text-xs text-gray-600">Lectures</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-gray-900">{students}k</div>
            <div className="text-xs text-gray-600">Students</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-gray-900">{resources}</div>
            <div className="text-xs text-gray-600">Resources</div>
          </div>
        </div>

        <div className="mb-4">
          <h4 className="text-sm font-semibold text-gray-900 mb-3">Key Topics</h4>
          <div className="flex flex-wrap gap-2">
            {topics.slice(0, 3).map((topic, index) => (
              <span
                key={index}
                className="bg-gray-100 text-gray-700 text-xs px-3 py-1 rounded-full"
              >
                {topic}
              </span>
            ))}
            {topics.length > 3 && (
              <span className="bg-gray-100 text-gray-700 text-xs px-3 py-1 rounded-full">
                +{topics.length - 3} more
              </span>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2">
          <Link
            to={`/course/${slug}`}
            className="w-full flex items-center justify-center bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors duration-200"
          >
            <BookOpen className="h-4 w-4 mr-2" />
            <span>Start Learning</span>
          </Link>
          
          <Link
            to={`/lectures/${slug}`}
            className="w-full flex items-center justify-center border border-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-50 transition-colors duration-200"
          >
            <Play className="h-4 w-4 mr-2" />
            <span>Watch Lectures</span>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default EngineeringCard;