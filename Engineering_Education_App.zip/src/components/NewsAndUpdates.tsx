import React from 'react';
import { Calendar, User, ArrowRight, TrendingUp } from 'lucide-react';

const NewsAndUpdates: React.FC = () => {
  const news = [
    {
      title: 'Revolutionary Battery Technology Breakthrough',
      excerpt: 'Scientists develop new lithium-metal batteries with 10x longer life...',
      author: 'Dr. Sarah Chen',
      date: '2025-01-12',
      category: 'Chemical Engineering',
      readTime: '5 min read',
      image: 'https://images.pexels.com/photos/3735218/pexels-photo-3735218.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      title: 'AI-Powered Structural Design Changes Construction',
      excerpt: 'New machine learning algorithms optimize building designs for safety and cost...',
      author: 'Prof. Michael Rodriguez',
      date: '2025-01-10',
      category: 'Civil Engineering',
      readTime: '7 min read',
      image: 'https://images.pexels.com/photos/3862132/pexels-photo-3862132.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      title: 'Quantum Computing Milestone Achieved',
      excerpt: 'Researchers demonstrate practical quantum advantage in optimization problems...',
      author: 'Dr. Emily Watson',
      date: '2025-01-08',
      category: 'Computer Engineering',
      readTime: '6 min read',
      image: 'https://images.pexels.com/photos/2582937/pexels-photo-2582937.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
  ];

  const trendingTopics = [
    'Sustainable Engineering',
    'Green Energy Solutions',
    'AI in Manufacturing',
    'Space Engineering',
    'Biomedical Innovations',
    '3D Printing Applications',
  ];

  return (
    <section id="news" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Latest News & Updates
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Stay informed about the latest breakthroughs, innovations, and trends 
            shaping the future of engineering.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* News Articles */}
          <div className="lg:col-span-2 space-y-8">
            {news.map((article, index) => (
              <article
                key={index}
                className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow duration-300 overflow-hidden group"
              >
                <div className="md:flex">
                  <div className="md:w-1/3">
                    <img
                      src={article.image}
                      alt={article.title}
                      className="w-full h-48 md:h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="md:w-2/3 p-6">
                    <div className="flex items-center space-x-4 mb-3">
                      <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">
                        {article.category}
                      </span>
                      <span className="text-sm text-gray-500">{article.readTime}</span>
                    </div>
                    
                    <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors duration-200">
                      {article.title}
                    </h3>
                    
                    <p className="text-gray-600 mb-4">{article.excerpt}</p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <User className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-600">{article.author}</span>
                        <Calendar className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-600">{article.date}</span>
                      </div>
                      
                      <button className="flex items-center space-x-1 text-blue-600 hover:text-blue-700 font-medium group-hover:translate-x-1 transition-transform duration-200">
                        <span>Read More</span>
                        <ArrowRight className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Trending Topics */}
            <div className="bg-white rounded-xl p-6 shadow-sm">
              <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                <TrendingUp className="h-5 w-5 text-green-600 mr-2" />
                Trending Topics
              </h3>
              
              <div className="space-y-3">
                {trendingTopics.map((topic, index) => (
                  <a
                    key={index}
                    href="#"
                    className="block text-gray-700 hover:text-blue-600 hover:bg-blue-50 px-3 py-2 rounded-lg transition-colors duration-200"
                  >
                    #{topic.replace(' ', '')}
                  </a>
                ))}
              </div>
            </div>

            {/* Newsletter Signup */}
            <div className="bg-gradient-to-r from-blue-600 to-teal-600 rounded-xl p-6 text-white">
              <h3 className="text-xl font-bold mb-2">Stay Updated</h3>
              <p className="text-blue-100 mb-4">
                Get the latest engineering news and insights delivered to your inbox.
              </p>
              
              <div className="space-y-3">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="w-full px-4 py-2 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-white/50"
                />
                <button className="w-full bg-white text-blue-600 py-2 rounded-lg font-semibold hover:bg-blue-50 transition-colors duration-200">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default NewsAndUpdates;