import React from 'react';
import { Calculator, Ruler, Zap, Cog, Beaker, Code } from 'lucide-react';

const EngineeringTools: React.FC = () => {
  const tools = [
    {
      icon: Calculator,
      title: 'Unit Converter',
      description: 'Convert between different units of measurement',
      category: 'General',
      color: 'bg-blue-100 text-blue-600',
    },
    {
      icon: Ruler,
      title: 'Beam Calculator',
      description: 'Calculate beam deflection and stress',
      category: 'Civil',
      color: 'bg-green-100 text-green-600',
    },
    {
      icon: Zap,
      title: 'Circuit Simulator',
      description: 'Simulate and analyze electrical circuits',
      category: 'Electrical',
      color: 'bg-yellow-100 text-yellow-600',
    },
    {
      icon: Cog,
      title: 'Gear Calculator',
      description: 'Design and calculate gear ratios',
      category: 'Mechanical',
      color: 'bg-red-100 text-red-600',
    },
    {
      icon: Beaker,
      title: 'Process Simulator',
      description: 'Simulate chemical processes and reactions',
      category: 'Chemical',
      color: 'bg-purple-100 text-purple-600',
    },
    {
      icon: Code,
      title: 'Algorithm Visualizer',
      description: 'Visualize data structures and algorithms',
      category: 'Software',
      color: 'bg-teal-100 text-teal-600',
    },
  ];

  return (
    <section id="tools" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Engineering Tools
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Powerful calculators, simulators, and design tools to help you solve engineering problems 
            and visualize complex concepts.
          </p>
        </div>

        {/* Tools Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {tools.map((tool, index) => (
            <div
              key={index}
              className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 group"
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`inline-flex items-center justify-center w-12 h-12 rounded-lg ${tool.color}`}>
                  <tool.icon className="h-6 w-6" />
                </div>
                <span className="bg-gray-100 text-gray-600 text-xs px-2 py-1 rounded-full">
                  {tool.category}
                </span>
              </div>
              
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{tool.title}</h3>
              <p className="text-gray-600 mb-4">{tool.description}</p>
              
              <button className="text-blue-600 hover:text-blue-700 font-medium group-hover:translate-x-1 transition-transform duration-200">
                Open Tool →
              </button>
            </div>
          ))}
        </div>

        {/* Featured Tool */}
        <div className="bg-gradient-to-r from-blue-600 to-teal-600 rounded-2xl p-8 text-white text-center">
          <h3 className="text-2xl font-bold mb-4">
            🔧 Engineering Toolkit Pro
          </h3>
          <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
            Access our complete suite of professional engineering tools, including advanced calculators, 
            design software, and simulation environments.
          </p>
          <button className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors duration-200">
            Explore All Tools
          </button>
        </div>
      </div>
    </section>
  );
};

export default EngineeringTools;