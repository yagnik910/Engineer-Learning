import React from 'react';
import { TrendingUp, Users, DollarSign, MapPin, Briefcase, Star } from 'lucide-react';

const CareerGuidance: React.FC = () => {
  const careerStats = [
    {
      icon: DollarSign,
      title: 'Average Salary',
      value: '$85,000',
      description: 'Starting salary for engineering graduates',
      color: 'text-green-600',
    },
    {
      icon: TrendingUp,
      title: 'Job Growth',
      value: '4-8%',
      description: 'Expected growth rate through 2030',
      color: 'text-blue-600',
    },
    {
      icon: Users,
      title: 'Open Positions',
      value: '2.3M+',
      description: 'Engineering jobs available globally',
      color: 'text-purple-600',
    },
    {
      icon: Star,
      title: 'Job Satisfaction',
      value: '4.2/5',
      description: 'Average satisfaction rating',
      color: 'text-yellow-600',
    },
  ];

  const topIndustries = [
    { name: 'Technology', percentage: 35, color: 'bg-blue-500' },
    { name: 'Manufacturing', percentage: 25, color: 'bg-green-500' },
    { name: 'Construction', percentage: 20, color: 'bg-orange-500' },
    { name: 'Energy', percentage: 15, color: 'bg-purple-500' },
    { name: 'Healthcare', percentage: 5, color: 'bg-pink-500' },
  ];

  return (
    <section id="careers" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Career Guidance
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Explore career opportunities, salary insights, and industry trends to make informed 
            decisions about your engineering future.
          </p>
        </div>

        {/* Career Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {careerStats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 mb-4`}>
                <stat.icon className={`h-8 w-8 ${stat.color}`} />
              </div>
              <div className={`text-3xl font-bold ${stat.color} mb-2`}>{stat.value}</div>
              <div className="text-lg font-semibold text-gray-900 mb-1">{stat.title}</div>
              <div className="text-sm text-gray-600">{stat.description}</div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Top Industries */}
          <div className="bg-gray-50 rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
              <Briefcase className="h-6 w-6 text-blue-600 mr-2" />
              Top Industries
            </h3>
            
            <div className="space-y-4">
              {topIndustries.map((industry, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-3 h-3 rounded-full ${industry.color}`}></div>
                    <span className="font-medium text-gray-900">{industry.name}</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="bg-gray-200 rounded-full h-2 w-24">
                      <div 
                        className={`h-2 rounded-full ${industry.color}`}
                        style={{ width: `${industry.percentage}%` }}
                      ></div>
                    </div>
                    <span className="text-sm text-gray-600 w-8">{industry.percentage}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Career Resources */}
          <div className="bg-gradient-to-br from-blue-50 to-teal-50 rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
              <MapPin className="h-6 w-6 text-teal-600 mr-2" />
              Career Resources
            </h3>
            
            <div className="space-y-4">
              {[
                'Resume Templates for Engineers',
                'Interview Preparation Guide',
                'Salary Negotiation Tips',
                'Professional Networking',
                'Certification Programs',
                'Industry Mentorship',
              ].map((resource, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-white rounded-lg hover:shadow-md transition-shadow duration-200">
                  <span className="text-gray-800">{resource}</span>
                  <button className="text-blue-600 hover:text-blue-700">
                    View →
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CareerGuidance;