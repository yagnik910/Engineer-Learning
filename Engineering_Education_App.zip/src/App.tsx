import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Hero from './components/Hero';
import EngineeringDisciplines from './components/EngineeringDisciplines';
import StudyResources from './components/StudyResources';
import EngineeringTools from './components/EngineeringTools';
import CareerGuidance from './components/CareerGuidance';
import NewsAndUpdates from './components/NewsAndUpdates';
import Footer from './components/Footer';
import CoursePage from './pages/CoursePage';
import VideoLecturePage from './pages/VideoLecturePage';
import ToolsPage from './pages/ToolsPage';

function HomePage() {
  return (
    <>
      <Hero />
      <EngineeringDisciplines />
      <StudyResources />
      <EngineeringTools />
      <CareerGuidance />
      <NewsAndUpdates />
    </>
  );
}

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-white">
        <Header />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/course/:discipline" element={<CoursePage />} />
          <Route path="/lectures/:discipline" element={<VideoLecturePage />} />
          <Route path="/tools" element={<ToolsPage />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;