import React, { useState } from 'react';
import { 
  Calculator, 
  Ruler, 
  Zap, 
  Cog, 
  Beaker, 
  Code,
  Search,
  Filter,
  Star,
  Users,
  Play,
  Download
} from 'lucide-react';

const ToolsPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedTool, setSelectedTool] = useState<number | null>(null);

  const categories = [
    { id: 'all', name: 'All Tools', count: 24 },
    { id: 'civil', name: 'Civil Engineering', count: 6 },
    { id: 'mechanical', name: 'Mechanical', count: 5 },
    { id: 'electrical', name: 'Electrical', count: 4 },
    { id: 'software', name: 'Software', count: 4 },
    { id: 'chemical', name: 'Chemical', count: 3 },
    { id: 'general', name: 'General', count: 2 }
  ];

  const tools = [
    {
      id: 1,
      icon: Calculator,
      title: 'Unit Converter',
      description: 'Convert between different units of measurement including length, weight, temperature, and more',
      category: 'general',
      rating: 4.8,
      users: 15000,
      features: ['Length conversion', 'Weight conversion', 'Temperature conversion', 'Area conversion'],
      color: 'bg-blue-100 text-blue-600',
      interactive: true
    },
    {
      id: 2,
      icon: Ruler,
      title: 'Beam Calculator',
      description: 'Calculate beam deflection, stress, and moment for various loading conditions',
      category: 'civil',
      rating: 4.9,
      users: 8500,
      features: ['Simply supported beams', 'Cantilever beams', 'Fixed beams', 'Distributed loads'],
      color: 'bg-green-100 text-green-600',
      interactive: true
    },
    {
      id: 3,
      icon: Zap,
      title: 'Circuit Simulator',
      description: 'Simulate and analyze electrical circuits with interactive components',
      category: 'electrical',
      rating: 4.7,
      users: 12000,
      features: ['AC/DC analysis', 'Component library', 'Oscilloscope', 'Frequency analysis'],
      color: 'bg-yellow-100 text-yellow-600',
      interactive: true
    },
    {
      id: 4,
      icon: Cog,
      title: 'Gear Calculator',
      description: 'Design and calculate gear ratios, speeds, and torques for mechanical systems',
      category: 'mechanical',
      rating: 4.6,
      users: 6800,
      features: ['Gear ratios', 'Speed calculations', 'Torque analysis', 'Efficiency calculations'],
      color: 'bg-red-100 text-red-600',
      interactive: true
    },
    {
      id: 5,
      icon: Beaker,
      title: 'Process Simulator',
      description: 'Simulate chemical processes and reactions with thermodynamic calculations',
      category: 'chemical',
      rating: 4.5,
      users: 4200,
      features: ['Mass balance', 'Energy balance', 'Phase diagrams', 'Reaction kinetics'],
      color: 'bg-purple-100 text-purple-600',
      interactive: true
    },
    {
      id: 6,
      title: 'Algorithm Visualizer',
      icon: Code,
      description: 'Visualize data structures and algorithms with step-by-step animations',
      category: 'software',
      rating: 4.8,
      users: 18000,
      features: ['Sorting algorithms', 'Graph algorithms', 'Tree structures', 'Dynamic programming'],
      color: 'bg-teal-100 text-teal-600',
      interactive: true
    }
  ];

  const filteredTools = tools.filter(tool => {
    const matchesSearch = tool.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         tool.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || tool.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const UnitConverterTool = () => {
    const [fromValue, setFromValue] = useState('');
    const [fromUnit, setFromUnit] = useState('meters');
    const [toUnit, setToUnit] = useState('feet');
    const [result, setResult] = useState('');

    const conversions = {
      meters: { feet: 3.28084, inches: 39.3701, centimeters: 100 },
      feet: { meters: 0.3048, inches: 12, centimeters: 30.48 },
      inches: { meters: 0.0254, feet: 0.0833, centimeters: 2.54 },
      centimeters: { meters: 0.01, feet: 0.0328, inches: 0.3937 }
    };

    const handleConvert = () => {
      if (!fromValue) return;
      const value = parseFloat(fromValue);
      if (fromUnit === toUnit) {
        setResult(value.toString());
      } else {
        const converted = value * conversions[fromUnit][toUnit];
        setResult(converted.toFixed(4));
      }
    };

    return (
      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <h3 className="text-lg font-semibold mb-4">Unit Converter</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">From</label>
            <div className="flex space-x-2">
              <input
                type="number"
                value={fromValue}
                onChange={(e) => setFromValue(e.target.value)}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Enter value"
              />
              <select
                value={fromUnit}
                onChange={(e) => setFromUnit(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="meters">Meters</option>
                <option value="feet">Feet</option>
                <option value="inches">Inches</option>
                <option value="centimeters">Centimeters</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">To</label>
            <div className="flex space-x-2">
              <input
                type="text"
                value={result}
                readOnly
                className="flex-1 px-3 py-2 border border-gray-300 rounded-md bg-gray-50"
                placeholder="Result"
              />
              <select
                value={toUnit}
                onChange={(e) => setToUnit(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="meters">Meters</option>
                <option value="feet">Feet</option>
                <option value="inches">Inches</option>
                <option value="centimeters">Centimeters</option>
              </select>
            </div>
          </div>
        </div>
        <button
          onClick={handleConvert}
          className="mt-4 w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
        >
          Convert
        </button>
      </div>
    );
  };

  return (
    <div className="pt-16 min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Engineering Tools & Calculators
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Professional-grade tools and calculators to solve complex engineering problems. 
            All tools are free to use and designed by engineering experts.
          </p>
        </div>

        {/* Search and Filter */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search tools..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Filter className="h-5 w-5 text-gray-400" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.name} ({category.count})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Tools Grid */}
          <div className="lg:col-span-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {filteredTools.map((tool) => (
                <div
                  key={tool.id}
                  className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 group cursor-pointer"
                  onClick={() => setSelectedTool(selectedTool === tool.id ? null : tool.id)}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className={`inline-flex items-center justify-center w-12 h-12 rounded-lg ${tool.color}`}>
                      <tool.icon className="h-6 w-6" />
                    </div>
                    <div className="text-right">
                      <div className="flex items-center text-sm text-gray-600">
                        <Star className="h-4 w-4 text-yellow-400 mr-1" />
                        <span>{tool.rating}</span>
                      </div>
                      <div className="flex items-center text-xs text-gray-500 mt-1">
                        <Users className="h-3 w-3 mr-1" />
                        <span>{tool.users.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                  
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{tool.title}</h3>
                  <p className="text-gray-600 mb-4">{tool.description}</p>
                  
                  <div className="mb-4">
                    <h4 className="text-sm font-medium text-gray-900 mb-2">Features:</h4>
                    <div className="flex flex-wrap gap-1">
                      {tool.features.slice(0, 2).map((feature, index) => (
                        <span
                          key={index}
                          className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded"
                        >
                          {feature}
                        </span>
                      ))}
                      {tool.features.length > 2 && (
                        <span className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded">
                          +{tool.features.length - 2} more
                        </span>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    <button className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center justify-center">
                      <Play className="h-4 w-4 mr-2" />
                      Use Tool
                    </button>
                    <button className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors duration-200">
                      <Download className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Interactive Tool Demo */}
            {selectedTool === 1 && <UnitConverterTool />}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Categories */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold mb-4">Categories</h3>
              <div className="space-y-2">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                      selectedCategory === category.id
                        ? 'bg-blue-100 text-blue-700'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <span>{category.name}</span>
                      <span className="text-sm text-gray-500">{category.count}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Popular Tools */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold mb-4">Most Popular</h3>
              <div className="space-y-3">
                {tools.slice(0, 3).map((tool) => (
                  <div key={tool.id} className="flex items-center space-x-3">
                    <div className={`w-8 h-8 rounded ${tool.color} flex items-center justify-center`}>
                      <tool.icon className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-gray-900 text-sm">{tool.title}</div>
                      <div className="text-xs text-gray-500">
                        ⭐ {tool.rating} • {tool.users.toLocaleString()} users
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Help */}
            <div className="bg-gradient-to-r from-blue-600 to-teal-600 rounded-lg p-6 text-white">
              <h3 className="text-lg font-semibold mb-2">Need Help?</h3>
              <p className="text-blue-100 text-sm mb-4">
                Check out our comprehensive guides and tutorials for each tool.
              </p>
              <button className="w-full bg-white text-blue-600 py-2 rounded-lg font-medium hover:bg-blue-50 transition-colors">
                View Tutorials
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ToolsPage;