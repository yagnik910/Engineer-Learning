import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Play, 
  Pause, 
  Volume2, 
  Maximize, 
  Settings, 
  ChevronRight,
  Clock,
  CheckCircle,
  Lock,
  BookOpen,
  Download,
  MessageCircle,
  ThumbsUp,
  Share
} from 'lucide-react';

const VideoLecturePage: React.FC = () => {
  const { discipline } = useParams();
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentLecture, setCurrentLecture] = useState(0);

  // Mock lecture data
  const courseTitle = discipline?.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase()) || 'Engineering Course';
  
  const lectures = [
    {
      id: 1,
      title: 'Introduction to Engineering Principles',
      duration: '15:30',
      description: 'Welcome to the course! In this introductory lecture, we\'ll cover the fundamental principles that form the foundation of engineering.',
      videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
      completed: true,
      free: true,
      views: 12500,
      likes: 890,
      transcript: 'Welcome to our comprehensive engineering course. Today we will explore the fundamental principles...',
      resources: [
        { name: 'Lecture Slides', type: 'PDF', size: '2.3 MB' },
        { name: 'Practice Problems', type: 'PDF', size: '1.8 MB' }
      ]
    },
    {
      id: 2,
      title: 'Mathematical Foundations',
      duration: '22:45',
      description: 'Explore the essential mathematical concepts that every engineer needs to master.',
      videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
      completed: true,
      free: true,
      views: 10200,
      likes: 756,
      transcript: 'Mathematics is the language of engineering. In this lecture, we will cover...',
      resources: [
        { name: 'Math Reference Sheet', type: 'PDF', size: '1.5 MB' },
        { name: 'Calculator Guide', type: 'PDF', size: '900 KB' }
      ]
    },
    {
      id: 3,
      title: 'Problem Solving Methodologies',
      duration: '28:15',
      description: 'Learn systematic approaches to solving complex engineering problems.',
      videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
      completed: false,
      free: false,
      views: 8900,
      likes: 623,
      transcript: 'Problem solving is at the heart of engineering. Let\'s explore various methodologies...',
      resources: [
        { name: 'Problem Solving Framework', type: 'PDF', size: '2.1 MB' },
        { name: 'Case Studies', type: 'PDF', size: '3.2 MB' }
      ]
    },
    {
      id: 4,
      title: 'Design Principles and Best Practices',
      duration: '35:20',
      description: 'Understand the core principles of engineering design and industry best practices.',
      videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
      completed: false,
      free: false,
      views: 7800,
      likes: 542,
      transcript: 'Good design is the foundation of successful engineering projects...',
      resources: [
        { name: 'Design Guidelines', type: 'PDF', size: '4.1 MB' },
        { name: 'Design Templates', type: 'ZIP', size: '8.5 MB' }
      ]
    }
  ];

  const currentLectureData = lectures[currentLecture];

  const handleLectureSelect = (index: number) => {
    if (lectures[index].free || lectures[index].completed) {
      setCurrentLecture(index);
    }
  };

  return (
    <div className="pt-16 min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Breadcrumb */}
        <div className="mb-6">
          <Link to="/" className="text-blue-600 hover:text-blue-700">
            Home
          </Link>
          <ChevronRight className="inline h-4 w-4 mx-2 text-gray-400" />
          <Link to={`/course/${discipline}`} className="text-blue-600 hover:text-blue-700">
            {courseTitle}
          </Link>
          <ChevronRight className="inline h-4 w-4 mx-2 text-gray-400" />
          <span className="text-gray-600">Video Lectures</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Video Player */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              {/* Video */}
              <div className="relative aspect-video bg-black">
                <iframe
                  src={currentLectureData.videoUrl}
                  title={currentLectureData.title}
                  className="w-full h-full"
                  allowFullScreen
                />
                
                {/* Video Controls Overlay */}
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                  <div className="flex items-center justify-between text-white">
                    <div className="flex items-center space-x-4">
                      <button
                        onClick={() => setIsPlaying(!isPlaying)}
                        className="p-2 hover:bg-white/20 rounded-full transition-colors"
                      >
                        {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
                      </button>
                      <div className="flex items-center space-x-2">
                        <div className="w-32 h-1 bg-white/30 rounded-full">
                          <div className="w-1/3 h-full bg-red-500 rounded-full"></div>
                        </div>
                        <span className="text-sm">5:30 / {currentLectureData.duration}</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <button className="p-2 hover:bg-white/20 rounded-full transition-colors">
                        <Volume2 className="h-5 w-5" />
                      </button>
                      <button className="p-2 hover:bg-white/20 rounded-full transition-colors">
                        <Settings className="h-5 w-5" />
                      </button>
                      <button className="p-2 hover:bg-white/20 rounded-full transition-colors">
                        <Maximize className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Video Info */}
              <div className="p-6">
                <h1 className="text-2xl font-bold text-gray-900 mb-2">
                  {currentLectureData.title}
                </h1>
                
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-4 text-sm text-gray-600">
                    <span>{currentLectureData.views.toLocaleString()} views</span>
                    <span>•</span>
                    <span>{currentLectureData.duration}</span>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    <button className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors">
                      <ThumbsUp className="h-5 w-5" />
                      <span>{currentLectureData.likes}</span>
                    </button>
                    <button className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors">
                      <Share className="h-5 w-5" />
                      <span>Share</span>
                    </button>
                    <button className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors">
                      <Download className="h-5 w-5" />
                      <span>Download</span>
                    </button>
                  </div>
                </div>
                
                <p className="text-gray-700 mb-6">{currentLectureData.description}</p>
                
                {/* Tabs */}
                <div className="border-b border-gray-200">
                  <nav className="flex space-x-8">
                    <button className="py-2 px-1 border-b-2 border-blue-500 text-blue-600 font-medium text-sm">
                      Resources
                    </button>
                    <button className="py-2 px-1 border-b-2 border-transparent text-gray-500 hover:text-gray-700 font-medium text-sm">
                      Transcript
                    </button>
                    <button className="py-2 px-1 border-b-2 border-transparent text-gray-500 hover:text-gray-700 font-medium text-sm">
                      Comments
                    </button>
                  </nav>
                </div>
                
                {/* Resources */}
                <div className="mt-6">
                  <h3 className="text-lg font-semibold mb-4">Lecture Resources</h3>
                  <div className="space-y-3">
                    {currentLectureData.resources.map((resource, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                            <BookOpen className="h-5 w-5 text-blue-600" />
                          </div>
                          <div>
                            <div className="font-medium text-gray-900">{resource.name}</div>
                            <div className="text-sm text-gray-600">{resource.type} • {resource.size}</div>
                          </div>
                        </div>
                        <button className="text-blue-600 hover:text-blue-700 font-medium">
                          Download
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Lecture List */}
          <div className="bg-white rounded-lg shadow-sm">
            <div className="p-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">Course Content</h2>
              <p className="text-sm text-gray-600">{lectures.length} lectures</p>
            </div>
            
            <div className="max-h-96 overflow-y-auto">
              {lectures.map((lecture, index) => (
                <div
                  key={lecture.id}
                  className={`p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50 transition-colors ${
                    index === currentLecture ? 'bg-blue-50 border-l-4 border-l-blue-500' : ''
                  }`}
                  onClick={() => handleLectureSelect(index)}
                >
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 mt-1">
                      {lecture.completed ? (
                        <CheckCircle className="h-5 w-5 text-green-500" />
                      ) : lecture.free ? (
                        <Play className="h-5 w-5 text-blue-500" />
                      ) : (
                        <Lock className="h-5 w-5 text-gray-400" />
                      )}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h3 className={`text-sm font-medium ${
                          index === currentLecture ? 'text-blue-600' : 'text-gray-900'
                        } truncate`}>
                          {lecture.title}
                        </h3>
                        {lecture.free && (
                          <span className="ml-2 bg-green-100 text-green-800 text-xs px-2 py-1 rounded">
                            Free
                          </span>
                        )}
                      </div>
                      
                      <div className="flex items-center mt-1 text-xs text-gray-500">
                        <Clock className="h-3 w-3 mr-1" />
                        <span>{lecture.duration}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="p-4 bg-gray-50">
              <Link
                to={`/course/${discipline}`}
                className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-700 transition-colors duration-200 flex items-center justify-center"
              >
                <BookOpen className="h-4 w-4 mr-2" />
                View Full Course
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoLecturePage;