import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Play, 
  BookOpen, 
  Clock, 
  Users, 
  Star, 
  Download, 
  CheckCircle, 
  Lock,
  ChevronRight,
  Award,
  Globe
} from 'lucide-react';

const CoursePage: React.FC = () => {
  const { discipline } = useParams();
  const [activeTab, setActiveTab] = useState('overview');

  // Mock course data - in real app, this would come from API
  const courseData = {
    title: discipline?.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase()) || 'Engineering Course',
    instructor: 'Dr. Sarah Johnson',
    rating: 4.8,
    students: 12500,
    duration: '40 hours',
    lectures: 89,
    level: 'Beginner to Advanced',
    language: 'English',
    certificate: true,
    price: 'Free',
    description: 'Master the fundamentals and advanced concepts of engineering with hands-on projects, real-world applications, and expert guidance.',
    whatYouLearn: [
      'Core engineering principles and theories',
      'Practical problem-solving techniques',
      'Industry-standard tools and software',
      'Real-world project experience',
      'Professional best practices',
      'Career preparation and guidance'
    ],
    curriculum: [
      {
        title: 'Introduction and Fundamentals',
        lectures: 12,
        duration: '4 hours',
        completed: true,
        lessons: [
          { title: 'Course Introduction', duration: '15 min', completed: true, free: true },
          { title: 'Engineering Principles', duration: '45 min', completed: true, free: true },
          { title: 'Mathematical Foundations', duration: '60 min', completed: false, free: false },
          { title: 'Problem Solving Methods', duration: '30 min', completed: false, free: false }
        ]
      },
      {
        title: 'Core Concepts',
        lectures: 18,
        duration: '8 hours',
        completed: false,
        lessons: [
          { title: 'Design Principles', duration: '50 min', completed: false, free: false },
          { title: 'Materials and Properties', duration: '40 min', completed: false, free: false },
          { title: 'Analysis Techniques', duration: '55 min', completed: false, free: false }
        ]
      },
      {
        title: 'Advanced Applications',
        lectures: 25,
        duration: '12 hours',
        completed: false,
        lessons: [
          { title: 'Advanced Design Methods', duration: '65 min', completed: false, free: false },
          { title: 'Optimization Techniques', duration: '45 min', completed: false, free: false },
          { title: 'Case Studies', duration: '70 min', completed: false, free: false }
        ]
      },
      {
        title: 'Projects and Applications',
        lectures: 20,
        duration: '10 hours',
        completed: false,
        lessons: [
          { title: 'Project Planning', duration: '40 min', completed: false, free: false },
          { title: 'Implementation', duration: '90 min', completed: false, free: false },
          { title: 'Testing and Validation', duration: '60 min', completed: false, free: false }
        ]
      }
    ]
  };

  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'curriculum', label: 'Curriculum' },
    { id: 'instructor', label: 'Instructor' },
    { id: 'reviews', label: 'Reviews' }
  ];

  return (
    <div className="pt-16 min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-teal-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <div className="mb-4">
                <Link to="/" className="text-blue-200 hover:text-white">
                  Home
                </Link>
                <ChevronRight className="inline h-4 w-4 mx-2" />
                <span>Courses</span>
                <ChevronRight className="inline h-4 w-4 mx-2" />
                <span>{courseData.title}</span>
              </div>
              
              <h1 className="text-4xl font-bold mb-4">{courseData.title}</h1>
              <p className="text-xl text-blue-100 mb-6">{courseData.description}</p>
              
              <div className="flex flex-wrap items-center gap-6 mb-6">
                <div className="flex items-center">
                  <Star className="h-5 w-5 text-yellow-400 mr-1" />
                  <span className="font-semibold">{courseData.rating}</span>
                  <span className="text-blue-200 ml-1">({courseData.students.toLocaleString()} students)</span>
                </div>
                <div className="flex items-center">
                  <Clock className="h-5 w-5 text-blue-200 mr-1" />
                  <span>{courseData.duration}</span>
                </div>
                <div className="flex items-center">
                  <Play className="h-5 w-5 text-blue-200 mr-1" />
                  <span>{courseData.lectures} lectures</span>
                </div>
                <div className="flex items-center">
                  <Globe className="h-5 w-5 text-blue-200 mr-1" />
                  <span>{courseData.language}</span>
                </div>
              </div>
              
              <div className="text-sm text-blue-200">
                Created by <span className="text-white font-semibold">{courseData.instructor}</span>
              </div>
            </div>
            
            {/* Course Card */}
            <div className="bg-white rounded-xl p-6 text-gray-900 h-fit">
              <div className="aspect-video bg-gray-200 rounded-lg mb-4 flex items-center justify-center">
                <Play className="h-12 w-12 text-gray-400" />
              </div>
              
              <div className="text-3xl font-bold text-green-600 mb-4">{courseData.price}</div>
              
              <button className="w-full bg-red-600 text-white py-3 rounded-lg font-semibold hover:bg-red-700 transition-colors duration-200 mb-3">
                Enroll Now
              </button>
              
              <Link
                to={`/lectures/${discipline}`}
                className="w-full border border-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-50 transition-colors duration-200 flex items-center justify-center"
              >
                <Play className="h-4 w-4 mr-2" />
                Preview Lectures
              </Link>
              
              <div className="mt-6 space-y-3 text-sm">
                <div className="flex items-center">
                  <Clock className="h-4 w-4 text-gray-500 mr-2" />
                  <span>{courseData.duration} on-demand video</span>
                </div>
                <div className="flex items-center">
                  <Download className="h-4 w-4 text-gray-500 mr-2" />
                  <span>Downloadable resources</span>
                </div>
                <div className="flex items-center">
                  <Award className="h-4 w-4 text-gray-500 mr-2" />
                  <span>Certificate of completion</span>
                </div>
                <div className="flex items-center">
                  <Users className="h-4 w-4 text-gray-500 mr-2" />
                  <span>Access to student community</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {/* Tabs */}
            <div className="bg-white rounded-lg shadow-sm mb-6">
              <div className="border-b border-gray-200">
                <nav className="flex space-x-8 px-6">
                  {tabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`py-4 px-1 border-b-2 font-medium text-sm ${
                        activeTab === tab.id
                          ? 'border-blue-500 text-blue-600'
                          : 'border-transparent text-gray-500 hover:text-gray-700'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </nav>
              </div>
              
              <div className="p-6">
                {activeTab === 'overview' && (
                  <div>
                    <h3 className="text-xl font-bold mb-4">What you'll learn</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-8">
                      {courseData.whatYouLearn.map((item, index) => (
                        <div key={index} className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                          <span className="text-gray-700">{item}</span>
                        </div>
                      ))}
                    </div>
                    
                    <h3 className="text-xl font-bold mb-4">Course Requirements</h3>
                    <ul className="list-disc list-inside text-gray-700 space-y-2 mb-8">
                      <li>Basic mathematics knowledge</li>
                      <li>Access to a computer with internet connection</li>
                      <li>Willingness to learn and practice</li>
                      <li>No prior engineering experience required</li>
                    </ul>
                    
                    <h3 className="text-xl font-bold mb-4">Course Description</h3>
                    <div className="text-gray-700 space-y-4">
                      <p>
                        This comprehensive course covers all essential aspects of {courseData.title.toLowerCase()}, 
                        from fundamental principles to advanced applications. You'll learn through a combination of 
                        theoretical concepts, practical exercises, and real-world projects.
                      </p>
                      <p>
                        Our expert instructors bring years of industry experience and academic expertise to provide 
                        you with the most current and relevant knowledge in the field. The course is designed to 
                        take you from beginner to advanced level, regardless of your starting point.
                      </p>
                      <p>
                        By the end of this course, you'll have the skills and knowledge needed to tackle complex 
                        engineering challenges and advance your career in this exciting field.
                      </p>
                    </div>
                  </div>
                )}
                
                {activeTab === 'curriculum' && (
                  <div>
                    <h3 className="text-xl font-bold mb-6">Course Curriculum</h3>
                    <div className="space-y-4">
                      {courseData.curriculum.map((section, sectionIndex) => (
                        <div key={sectionIndex} className="border border-gray-200 rounded-lg">
                          <div className="p-4 bg-gray-50 border-b border-gray-200">
                            <div className="flex items-center justify-between">
                              <h4 className="font-semibold text-gray-900">{section.title}</h4>
                              <div className="text-sm text-gray-600">
                                {section.lectures} lectures • {section.duration}
                              </div>
                            </div>
                          </div>
                          <div className="divide-y divide-gray-200">
                            {section.lessons.map((lesson, lessonIndex) => (
                              <div key={lessonIndex} className="p-4 flex items-center justify-between">
                                <div className="flex items-center">
                                  {lesson.completed ? (
                                    <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                                  ) : lesson.free ? (
                                    <Play className="h-5 w-5 text-blue-500 mr-3" />
                                  ) : (
                                    <Lock className="h-5 w-5 text-gray-400 mr-3" />
                                  )}
                                  <span className={lesson.completed ? 'text-gray-900' : 'text-gray-700'}>
                                    {lesson.title}
                                  </span>
                                  {lesson.free && (
                                    <span className="ml-2 bg-green-100 text-green-800 text-xs px-2 py-1 rounded">
                                      Free
                                    </span>
                                  )}
                                </div>
                                <span className="text-sm text-gray-500">{lesson.duration}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {activeTab === 'instructor' && (
                  <div>
                    <h3 className="text-xl font-bold mb-6">Meet Your Instructor</h3>
                    <div className="flex items-start space-x-4">
                      <div className="w-20 h-20 bg-gray-300 rounded-full flex items-center justify-center">
                        <Users className="h-8 w-8 text-gray-600" />
                      </div>
                      <div>
                        <h4 className="text-lg font-semibold text-gray-900">{courseData.instructor}</h4>
                        <p className="text-blue-600 mb-2">Professor of Engineering</p>
                        <div className="flex items-center space-x-4 text-sm text-gray-600 mb-4">
                          <span>⭐ 4.9 Instructor Rating</span>
                          <span>👥 25,000+ Students</span>
                          <span>🎓 15+ Courses</span>
                        </div>
                        <p className="text-gray-700">
                          Dr. Johnson is a renowned expert in engineering with over 15 years of experience in both 
                          academia and industry. She has published numerous research papers and has been recognized 
                          for her innovative teaching methods and student engagement.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
                
                {activeTab === 'reviews' && (
                  <div>
                    <h3 className="text-xl font-bold mb-6">Student Reviews</h3>
                    <div className="space-y-6">
                      {[
                        {
                          name: 'Alex Chen',
                          rating: 5,
                          date: '2 weeks ago',
                          review: 'Excellent course! The explanations are clear and the projects are very practical. I learned so much and feel confident applying these concepts in my work.'
                        },
                        {
                          name: 'Maria Rodriguez',
                          rating: 5,
                          date: '1 month ago',
                          review: 'Dr. Johnson is an amazing instructor. The course content is well-structured and the video quality is excellent. Highly recommended!'
                        },
                        {
                          name: 'David Kim',
                          rating: 4,
                          date: '2 months ago',
                          review: 'Great course overall. The theoretical concepts are explained well, though I would have liked more hands-on exercises. Still very valuable.'
                        }
                      ].map((review, index) => (
                        <div key={index} className="border-b border-gray-200 pb-6">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center">
                              <div className="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center mr-3">
                                <span className="text-sm font-semibold">{review.name[0]}</span>
                              </div>
                              <div>
                                <div className="font-semibold text-gray-900">{review.name}</div>
                                <div className="flex items-center">
                                  {[...Array(review.rating)].map((_, i) => (
                                    <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                                  ))}
                                </div>
                              </div>
                            </div>
                            <span className="text-sm text-gray-500">{review.date}</span>
                          </div>
                          <p className="text-gray-700">{review.review}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          {/* Sidebar */}
          <div className="space-y-6">
            {/* Related Courses */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-bold mb-4">Related Courses</h3>
              <div className="space-y-4">
                {[
                  'Advanced Engineering Mathematics',
                  'Engineering Design Principles',
                  'Materials Science Fundamentals'
                ].map((course, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-gray-200 rounded flex items-center justify-center">
                      <BookOpen className="h-6 w-6 text-gray-600" />
                    </div>
                    <div>
                      <div className="font-medium text-gray-900">{course}</div>
                      <div className="text-sm text-gray-600">⭐ 4.7 • 2.5k students</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CoursePage;